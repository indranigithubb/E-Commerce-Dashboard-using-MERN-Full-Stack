const express = require("express");
const cors = require("cors");

require("./db/config");
const User = require("./db/User");
const Product = require("./db/Product");
const app = express();

const Jwt = require("jsonwebtoken");
//define key 
const jwtkey = "e-comm";

//middleware
app.use(express.json());
app.use(cors());

//jwt used here 
app.post("/register", async (req, res) => {
//client sent json data, express.json middleware parse it thru json payload and send data in req.body
  console.log("Request received:", req.body);
  let user = new User(req.body);
  let result = await user.save();
  result = result.toObject();
  delete result.password;
  Jwt.sign({result}, jwtkey,{expiresIn : "60h"},(err,token)=>{
    if(err){
      res.send({result : "something is wrong"});
    }
    res.send({result,auth:token});
  })
});

//jwt used here 
app.post("/login", async(req,res)=>{
  if(req.body.email && req.body.password){
  let user = await User.findOne(req.body).select("-password");
  if(user){
    Jwt.sign({user}, jwtkey,{expiresIn : "60h"},(err,token)=>{
      if(err){
        res.send({result : "something is wrong"});
      }
      res.send({user,auth:token});
    })
  
  }else{
    res.send({"result " : "no result found"});
  }
}else{
  res.send({"result " : "no result found"});
}
})

//store the product data in the database
app.post("/add-product",verifyToken, async (req,res)=>{
  let product = new Product(req.body);
  let result = await product.save();
  res.send(result);

})
// app.post("/login",async(req,res)=>{
//     let user = await User.findOne(req.body);
//     res.send(user);
    // res.send(req.body);
// })

//fetch data from database
app.get("/products", async(req,res)=>{
  const products = await Product.find();
  if(products.length > 0){
    res.send(products);
  }else{
    res.send({result : "No data found"});
  }
})

//delete product
app.delete("/product/:id",verifyToken, async(req,res)=>{
  let result = await Product.deleteOne({_id : req.params.id});
  res.send(result);
})


//API to get single product 
app.get("/product/:id", async(req,res)=>{
  let result = await Product.findOne({_id : req.params.id});
  if(result){
    res.send(result)
  }else{
    res.send({"result": "no record found"});
  }
})

//update 
app.put("/product/:id",verifyToken,async(req,res)=>{
  let result = await Product.updateOne(
    {_id : req.params.id},
    {$set : req.body}   
)
res.send(result);
}
)

//search
app.get("/search/:key", verifyToken,async(req,res)=>{
  let result = await Product.find({
    "$or":[
      {
        name : {$regex : req.params.key}
       
      },
      {
        price : {$regex : req.params.key}
      },
      {
        category : {$regex : req.params.key}
      },
      {
        company : {$regex : req.params.key}
      }
    ]
  });
res.send(result);
})

function verifyToken(req,res,next){
   console.warn(req.headers['authorization']);
   let token = req.headers['authorization'];
   if(token){
    token = token.split(' ')[1];
   Jwt.verify(token,jwtkey,(err,valid)=>{
     if(err){
      res.send("please provide a valid token");
     }else{
      next();
     }
   });

   }else{
    res.send("please provide a token");
   }
//    next();
  }
   
app.listen(9000, () => {
  console.log("Server is running on port 9000");
});

