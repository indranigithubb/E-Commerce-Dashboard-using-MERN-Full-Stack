import React, { useState,useEffect } from "react";
import {useNavigate} from "react-router-dom";

const SignUp = () => {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();
  useEffect (()=>{
    const auth = localStorage.getItem("user");
    if(auth){
    navigate("/");
    }
  },[])
  

  const collectData = async () => {
   console.warn(name, email, password);
   //fetch is used to send http request to backend which is running at 4000
   const response = await fetch("http://localhost:9000/register",{
    method : "post",

    //it will show the output in node console
 headers: {
           "Content-Type": "application/json",
         },

    body:JSON.stringify({name,email,password}),
    
    });

    //show data in react console along with the data we fill in the form
      const data = await response.json();
       console.log("Success:", data);
       localStorage.setItem("user",JSON.stringify(data.result));
       localStorage.setItem("token",JSON.stringify(data.auth));
      
       navigate("/");
   
   };
 

  return (
    <div className="register">
      <h1>Register</h1>
      <input className = "inputbox" type = "text" placeholder="Enter Name" value ={name} onChange={(e)=>setName(e.target.value)}/>
      <input className = "inputbox" type = "text" placeholder="Enter Email" value ={email} onChange={(e)=>setEmail(e.target.value)}/>
     <input className = "inputbox" type = "password" placeholder="Enter Password" value ={password} onChange={(e)=>setPassword(e.target.value)}/>
     <button onClick={collectData} className = "appButton" type = "button">Sign Up</button>
      
    </div>
  );
};

export default SignUp;

