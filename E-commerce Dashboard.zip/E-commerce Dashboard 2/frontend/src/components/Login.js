import React from "react";
import { useState,useEffect } from "react";
import { useNavigate } from "react-router-dom";

const Login =()=>{

    const[email,setEmail] = useState("")
    const[password,setPassword]= useState("")
    const navigate = useNavigate();

    useEffect (()=>{
        const auth = localStorage.getItem("user");
        if(auth){
        navigate("/");
        }
      },[])
      
    
    const handlelogin = async () => {
        
        //fetch is used to send http request to backend which is running at 4000
        let result = await fetch("http://localhost:9000/login",{
         method : "post",
     
         //it will show the output in node console
      headers: {
                "Content-Type": "application/json",
              },
     
         body:JSON.stringify({email,password}),
         
         });
         const data = await result.json();
         console.log("Result:", data);
         if(data.auth){
            localStorage.setItem('user',JSON.stringify(data.user));
            localStorage.setItem('token',JSON.stringify(data.auth));
            navigate("/");
         }else{
            alert("please enter correct details");
         }
        
     
     };
   


   return(
    <div className = "login">
        <h1>Login</h1>
        <input type = "text" className= "inputbox" placeholder="Enter Email" value={email} onChange={(e)=>setEmail(e.target.value)}/>
        <input type = "password" className= "inputbox" placeholder="Enter Password" value={password} onChange={(e)=>setPassword(e.target.value)}/>
        <button onClick={handlelogin} className="appButton">Login</button>
    </div>
   )
}

export default Login;